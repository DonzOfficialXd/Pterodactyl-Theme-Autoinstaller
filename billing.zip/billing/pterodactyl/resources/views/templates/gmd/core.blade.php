@extends('templates/wrapper', [
    'css' => ['body' => 'bg-neutral-800'],
])
@section('container')

@endsection
